package com.example.MyVolunteer_api.constants;

public enum Role {
    VOLUNTEER,
    ORGANIZATION
}
