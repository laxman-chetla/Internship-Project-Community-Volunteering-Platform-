package com.example.MyVolunteer_api.constants;

public enum OpportunityStatus {
    ACTIVE,
    CLOSED,
    COMPLETED
}