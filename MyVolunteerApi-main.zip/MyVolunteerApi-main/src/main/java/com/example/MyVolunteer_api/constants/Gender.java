package com.example.MyVolunteer_api.constants;

public enum Gender {
    MALE,
    FEMALE
}
