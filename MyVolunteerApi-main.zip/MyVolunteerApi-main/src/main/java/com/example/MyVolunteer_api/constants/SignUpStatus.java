package com.example.MyVolunteer_api.constants;

public enum SignUpStatus {
    TAKEN,
    CANCELLED,
    COMPLETED
}